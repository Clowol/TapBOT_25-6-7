/******************** (C) COPYRIGHT 2024 *****************************************
 * 文件�? ：steer_data.c
 * 描述    ：舵机数据发�?
 * 硬件配置�?        
 * 版本    �?
 * 修改日期�?
 * 作�?   : 
 * 修改日志:
*********************************************************************************/ 
#include "steer_data.h"
#include "control_math.h"
#include "control_dispatcher.h"
#include "app_config.h"


//速度 Y1对应
float Y1_Speed_Arr[2][3] =				// 
{  
	//  �?     �?      �?
	{ STEER_Y1_IN_LEFT,     STEER_Y1_IN_MID,     STEER_Y1_IN_RIGHT},					// 
	{ STEER_SPEED_OUT_LEFT, STEER_SPEED_OUT_MID, STEER_SPEED_OUT_RIGHT}					// 
};


s16 SteerRunSpeed = 0;							//

u8 SteerRunMode = STEER_SPEED_MODE;
u8 SteerActualMode = STEER_MODE_UNKNOWN;


//异步写单个舵�?
u8 SteerDataBuf[13] = \
{
//  0     1     2     3     4     5     6     7     8     9     10    11    12     
//															写入�?
//    字头      ID   长度  指令 首地址  位置数据    时间数据    速度数据 	 校验							
	 0xFF, 0xFF, 0x01, 0x09, 0x03, 0x2A, 0x00, 0x08, 0x00, 0x00, 0xE8, 0x03, 0x00
};


//同步写多个舵�?位置 时间 速度
u8 SteerDataBuf_SYNC[36] = \
{
//  0     1     2     3     4     5     6     
//															写入�?数据
//    字头      ID   长度  指令 首地址 长度
   0xFF, 0xFF, 0xFE, 0x20, 0x83, 0x2A, 0x06, \

//	7     8     9     10    11    12    13
// 舵机
// ID 0   位置数据    时间数据    速度数据 	 
   0x00, 0x00, 0x08, 0x00, 0x00, 0xE8, 0x03, \
		
//	14    15    16    17    18    19    20
// 舵机
// ID 1   位置数据    时间数据    速度数据 	 
   0x01, 0x00, 0x08, 0x00, 0x00, 0xE8, 0x03, \

//	21    22    23    24    25    26    27
// 舵机
// ID 2   位置数据    时间数据    速度数据 	 
   0x02, 0x00, 0x08, 0x00, 0x00, 0xE8, 0x03, \

//	28    29    30    31    32    33    34
// 舵机
// ID 3   位置数据    时间数据    速度数据 	 
   0x03, 0x00, 0x08, 0x00, 0x00, 0xE8, 0x03, \

//	35
// 校验							
	 0x00
};


//同步写多个舵�?设置运行模式
u8 SteerDataBuf_RunMode[16] = \
{
//  0     1     2     3     4     5     6     
//															写入�?数据
//    字头      ID   长度  指令 首地址 长度
   0xFF, 0xFF, 0xFE, 0x0C, 0x83, 0x21, 0x01, \

//	7     8     9     10    11    12    13    14
// 舵机  运行  舵机  运行  舵机  运行  舵机  运行
// ID 0  模式  ID 1  模式  ID 2  模式  ID 3  模式
   0x00, 0x01, 0x01, 0x01, 0x02, 0x01, 0x03, 0x01, \

//	15
// 校验							
	 0x00
};


//同步写多个舵�?速度模式下设置运行速度
u8 SteerDataBuf_SpeedRun[20] = \
{
//  0     1     2     3     4     5     6     
//															写入�?数据
//    字头      ID   长度  指令 首地址 长度
   0xFF, 0xFF, 0xFE, 0x10, 0x83, 0x2E, 0x02, \

//	7     8     9     10    11    12    13    14    15    16    17    18
// 舵机              舵机              舵机              舵机
// ID 0   运行速度   ID 1   运行速度   ID 2   运行速度   ID 3   运行速度
   0x00, 0xE8, 0x03, 0x01, 0xE8, 0x03, 0x02, 0xE8, 0x03, 0x03, 0xE8, 0x03, \

//	19
// 校验
	 0x00
};


struct SteerSendMsg SteerSendMsg_1 = 
{
				1,		//	u8 	SteerID;			//ID�?
				0,		//	u8	AccData;			//加速度
		 2048,		//	s16 PosData;			//位置
				0,		//	u16	RunTime;			//运行时间
		 1000,		//	s16	SpeedData;		//速度
};


//4个电机的参数  2048 = 180°
struct SteerSendMsg SteerSendMsgArr[4] = 
{
//  SteerID,  AccData,  PosData,  RunTime,  SpeedData
	{    0,        0,       0,      0,        300},	
	{    1,        0,       0,      0,        300},	
	{    2,        0,       0,      0,        300},	
	{    3,        0,    2420,      0,        300}
};
static u8 Steer_Uart5SendByte(u8 data)
{
    u32 timeout = 0x0000FFFFU;

    USART_SendData(UART5, data);
    while(((UART5->SR & 0x40U) == 0U) && (timeout > 0U))
    {
        timeout--;
    }

    return (timeout > 0U) ? 1U : 0U;
}

static void Steer_Uart5SendBuf(const u8 *buf, u8 len)
{
    u8 i;

    if(buf == 0)
    {
        return;
    }

    for(i = 0U; i < len; i++)
    {
        if(Steer_Uart5SendByte(buf[i]) == 0U)
        {
            break;
        }
    }
}


/*
 * 函数名：SteerCheckSum
 * 描述  ：计算校验和
 * 输入  �?
 * 输出  ：无	
 */
static u8 SteerCheckSum(u8 * pusBuff, int iLen)
{
    int i;
    u8 usSum = 0;

		for(i = 1; i <=iLen; i++)
    {
        usSum = usSum +(u8)*pusBuff;
        pusBuff++;
    }
    
    return ~usSum;
}


/*
 * 函数名：SendSteerData
 * 描述  ：将发送给智能层的数据压入发送缓存中
 * 输入  ：无
 * 输出  ：无	
 */
void SendSteerData(void)
{
#if APP_USART2_TEXT_DEBUG
	 u8 Data_m = 0U;
#endif

	SteerDataBuf[2]=SteerSendMsg_1.SteerID;

	SteerDataBuf[6]=LBT(SteerSendMsg_1.PosData);
	SteerDataBuf[7]=HBT(SteerSendMsg_1.PosData);
	SteerDataBuf[8]=LBT(SteerSendMsg_1.RunTime);
	SteerDataBuf[9]=HBT(SteerSendMsg_1.RunTime);
	
 	SteerDataBuf[10]=LBT(SteerSendMsg_1.SpeedData);
	SteerDataBuf[11]=HBT(SteerSendMsg_1.SpeedData);

	SteerDataBuf[12] = SteerCheckSum(SteerDataBuf+2, 10);
	Steer_Uart5SendBuf(SteerDataBuf, 13U);

	//打印发送的数据
#if APP_USART2_TEXT_DEBUG
	swgPrtUx(USART2, "\r\n Steer Send: \r\n"); 
	for(Data_m=0;Data_m<13;Data_m++)
	{
		swgPrtUx(USART2, "%02X ", SteerDataBuf[Data_m]); 
	}
	swgPrtUx(USART2, "\r\n"); 	

#endif

	// DMA发�?
//	USART2_DMA_send(SteerDataBuf, 13);
}



/*
 * 函数名：SendSteer_SYNC_DataFun
 * 描述  ：同步写指令
 * 输入  ：无
 * 输出  ：无	
 */
void SendSteer_SYNC_DataFun(void)
{
	SteerDataBuf_SYNC[8]=LBT(SteerSendMsgArr[0].PosData);
	SteerDataBuf_SYNC[9]=HBT(SteerSendMsgArr[0].PosData);
	SteerDataBuf_SYNC[10]=LBT(SteerSendMsgArr[0].RunTime);
	SteerDataBuf_SYNC[11]=HBT(SteerSendMsgArr[0].RunTime);
 	SteerDataBuf_SYNC[12]=LBT(SteerSendMsgArr[0].SpeedData);
	SteerDataBuf_SYNC[13]=HBT(SteerSendMsgArr[0].SpeedData);

	SteerDataBuf_SYNC[15]=LBT(SteerSendMsgArr[1].PosData);
	SteerDataBuf_SYNC[16]=HBT(SteerSendMsgArr[1].PosData);
	SteerDataBuf_SYNC[17]=LBT(SteerSendMsgArr[1].RunTime);
	SteerDataBuf_SYNC[18]=HBT(SteerSendMsgArr[1].RunTime);
 	SteerDataBuf_SYNC[19]=LBT(SteerSendMsgArr[1].SpeedData);
	SteerDataBuf_SYNC[20]=HBT(SteerSendMsgArr[1].SpeedData);

	SteerDataBuf_SYNC[22]=LBT(SteerSendMsgArr[2].PosData);
	SteerDataBuf_SYNC[23]=HBT(SteerSendMsgArr[2].PosData);
	SteerDataBuf_SYNC[24]=LBT(SteerSendMsgArr[2].RunTime);
	SteerDataBuf_SYNC[25]=HBT(SteerSendMsgArr[2].RunTime);
 	SteerDataBuf_SYNC[26]=LBT(SteerSendMsgArr[2].SpeedData);
	SteerDataBuf_SYNC[27]=HBT(SteerSendMsgArr[2].SpeedData);

	SteerDataBuf_SYNC[29]=LBT(SteerSendMsgArr[3].PosData);
	SteerDataBuf_SYNC[30]=HBT(SteerSendMsgArr[3].PosData);
	SteerDataBuf_SYNC[31]=LBT(SteerSendMsgArr[3].RunTime);
	SteerDataBuf_SYNC[32]=HBT(SteerSendMsgArr[3].RunTime);
 	SteerDataBuf_SYNC[33]=LBT(SteerSendMsgArr[3].SpeedData);
	SteerDataBuf_SYNC[34]=HBT(SteerSendMsgArr[3].SpeedData);
	
	SteerDataBuf_SYNC[35] = SteerCheckSum(SteerDataBuf_SYNC+2, 33);
	Steer_Uart5SendBuf(SteerDataBuf_SYNC, 36U);

//	//打印发送的数据
//	swgPrtUx(USART2, "\r\n Steer Send: \r\n"); 
//	for(Data_m=0;Data_m<36;Data_m++)
//	{
//		swgPrtUx(USART2, "%02X ", SteerDataBuf_SYNC[Data_m]); 
//	}
//	swgPrtUx(USART2, "\r\n"); 	

//	USART2_DMA_send(SteerDataBuf, 36);

}



/*
 * 函数名：SendSteer_SYNC_SetMode
 * 描述  ：同步写指令
 * 输入  ：无
 * 输出  ：无	
 */
void SendSteer_SYNC_SetMode(u8 SetMode)
{
	if((SetMode != STEER_POSITION_MODE) && (SetMode != STEER_SPEED_MODE) && (SetMode != STEER_MIXED_MODE))
	{
		return;
	}

	SteerRunMode = SetMode;
	if(SteerActualMode == SetMode)
	{
		return;
	}
	
		if(SetMode == STEER_MIXED_MODE)
	{
		SteerDataBuf_RunMode[8] = STEER_POSITION_MODE;
		SteerDataBuf_RunMode[10] = STEER_POSITION_MODE;
		SteerDataBuf_RunMode[12] = STEER_POSITION_MODE;
		SteerDataBuf_RunMode[14] = STEER_SPEED_MODE;
	}
	else
	{
		SteerDataBuf_RunMode[8] = SetMode;
		SteerDataBuf_RunMode[10] = SetMode;
		SteerDataBuf_RunMode[12] = SetMode;
		SteerDataBuf_RunMode[14] = SetMode;
	}
	
	SteerDataBuf_RunMode[15] = SteerCheckSum(SteerDataBuf_RunMode+2, 13);
	Steer_Uart5SendBuf(SteerDataBuf_RunMode, 16U);

	SteerActualMode = SetMode;

//	//��ӡ���͵�����
//	swgPrtUx(USART2, "\r\n Steer Send: \r\n"); 
//	for(Data_m=0;Data_m<16;Data_m++)
//	{
//		swgPrtUx(USART2, "%02X ", SteerDataBuf_RunMode[Data_m]); 
//	}
//	swgPrtUx(USART2, "\r\n"); 	

//	USART2_DMA_send(SteerDataBuf_RunMode, 16);

}


/*
 * 函数名：SendSteer_SYNC_SpeedRun
 * 描述  ：同步写指令
 * 输入  ：无
 * 输出  ：无	
 */
void SendSteer_Position3_SYNC_DataFun(void)
{
	u8 buf[29] =
	{
		0xFF, 0xFF, 0xFE, 0x19, 0x83, 0x2A, 0x06,
		0x00, 0x00, 0x08, 0x00, 0x00, 0xE8, 0x03,
		0x01, 0x00, 0x08, 0x00, 0x00, 0xE8, 0x03,
		0x02, 0x00, 0x08, 0x00, 0x00, 0xE8, 0x03,
		0x00
	};

	buf[8] = LBT(SteerSendMsgArr[0].PosData);
	buf[9] = HBT(SteerSendMsgArr[0].PosData);
	buf[10] = LBT(SteerSendMsgArr[0].RunTime);
	buf[11] = HBT(SteerSendMsgArr[0].RunTime);
	buf[12] = LBT(SteerSendMsgArr[0].SpeedData);
	buf[13] = HBT(SteerSendMsgArr[0].SpeedData);

	buf[15] = LBT(SteerSendMsgArr[1].PosData);
	buf[16] = HBT(SteerSendMsgArr[1].PosData);
	buf[17] = LBT(SteerSendMsgArr[1].RunTime);
	buf[18] = HBT(SteerSendMsgArr[1].RunTime);
	buf[19] = LBT(SteerSendMsgArr[1].SpeedData);
	buf[20] = HBT(SteerSendMsgArr[1].SpeedData);

	buf[22] = LBT(SteerSendMsgArr[2].PosData);
	buf[23] = HBT(SteerSendMsgArr[2].PosData);
	buf[24] = LBT(SteerSendMsgArr[2].RunTime);
	buf[25] = HBT(SteerSendMsgArr[2].RunTime);
	buf[26] = LBT(SteerSendMsgArr[2].SpeedData);
	buf[27] = HBT(SteerSendMsgArr[2].SpeedData);

	buf[28] = SteerCheckSum(buf + 2, 26);


	Steer_Uart5SendBuf(buf, (u8)sizeof(buf));

}

void SendSteer_SYNC_SetDefaultMode(void)
{
	SendSteer_SYNC_SetMode(STEER_MIXED_MODE);
}

void SendSteer_Rotate_SpeedRun(void)
{
	u8 buf[11] =
	{
		0xFF, 0xFF, 0xFE, 0x07, 0x83, 0x2E, 0x02,
		STEER_ROTATE_SERVO_INDEX, 0x00, 0x00, 0x00
	};

	buf[8] = LBT(SteerSendMsgArr[STEER_ROTATE_SERVO_INDEX].SpeedData);
	buf[9] = HBT(SteerSendMsgArr[STEER_ROTATE_SERVO_INDEX].SpeedData);
	buf[10] = SteerCheckSum(buf + 2, 8);


	Steer_Uart5SendBuf(buf, (u8)sizeof(buf));

}
void SendSteer_SYNC_SpeedRun(void)
{
 	SteerDataBuf_SpeedRun[8]=LBT(SteerSendMsgArr[0].SpeedData);
	SteerDataBuf_SpeedRun[9]=HBT(SteerSendMsgArr[0].SpeedData);
 	SteerDataBuf_SpeedRun[11]=LBT(SteerSendMsgArr[1].SpeedData);
	SteerDataBuf_SpeedRun[12]=HBT(SteerSendMsgArr[1].SpeedData);
 	SteerDataBuf_SpeedRun[14]=LBT(SteerSendMsgArr[2].SpeedData);
	SteerDataBuf_SpeedRun[15]=HBT(SteerSendMsgArr[2].SpeedData);
 	SteerDataBuf_SpeedRun[17]=LBT(SteerSendMsgArr[3].SpeedData);
	SteerDataBuf_SpeedRun[18]=HBT(SteerSendMsgArr[3].SpeedData);
	
	SteerDataBuf_SpeedRun[19] = SteerCheckSum(SteerDataBuf_SpeedRun+2, 17);
	Steer_Uart5SendBuf(SteerDataBuf_SpeedRun, 20U);

//	//打印发送的数据
//	swgPrtUx(USART2, "\r\n Steer Send: \r\n"); 
//	for(Data_m=0;Data_m<20;Data_m++)
//	{
//		swgPrtUx(USART2, "%02X ", SteerDataBuf_SpeedRun[Data_m]); 
//	}
//	swgPrtUx(USART2, "\r\n"); 	

//	USART2_DMA_send(SteerDataBuf_SpeedRun, 20);

}


/*
 * 函数名：Steer_ControlProc
 * 描述  ：舵�? 速度控制
 * 输入  ：无
 * 输出  ：无	
 */
void Steer_ControlProc(void)
{
	SteerRunSpeed = (s16)control_map_3point(g_ctrl_cmd.steer_axis_cmd, Y1_Speed_Arr);
	SteerRunSpeed = -SteerRunSpeed;

	if(g_ctrl_cmd.steer_enable[STEER_ROTATE_SERVO_INDEX] != 0U)
	{
		SteerSpeedValue_SpeedMode(&SteerSendMsgArr[STEER_ROTATE_SERVO_INDEX].SpeedData, &SteerRunSpeed);
	}
	else
	{
		SteerSendMsgArr[STEER_ROTATE_SERVO_INDEX].SpeedData = 0;
	}

	if(SteerRunMode != STEER_MIXED_MODE)
	{
		SteerRunMode = STEER_MIXED_MODE;
		SendSteer_SYNC_SetDefaultMode();
	}

	SendSteer_Rotate_SpeedRun();
}

void SteerSpeedValue_SpeedMode(s16 * SpeedData, s16 * SteerSpeed)
{
	if(*SteerSpeed >= 0)
	{
		*SpeedData = *SteerSpeed;
		*SpeedData &= (~(1<<15));
	}
	else
	{
		*SpeedData = -*SteerSpeed;
		*SpeedData |= (1<<15);
	}
}


void RmtSteer_SpeedFun(void)
{
	Steer_ControlProc();
}



/******************* (C) COPYRIGHT 2026 END OF FILE ***************************/

