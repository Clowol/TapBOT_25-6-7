/******************** (C) COPYRIGHT 2024 *****************************************
 * 文件�? ：up_data.c
 * 描述    ：绝对编码器函数
 * 硬件配置:              
 * 版本    �?
 * 修改日期�?
 * 作�?   �?
 * 修改日志�?
*********************************************************************************/

#include "stm32f10x.h"                  // Device header
#include "can1.h"
#include "math.h"
#include "Encoder.h"

/**************************************************************************************/
//编码器CAN默认参数:标准�?数据�?默认波特�?00K,默认地址0x01
//                 64�?10bit分辨率（1024�?
/**************************************************************************************/

/**************************************************************************************/
//                          指令集格�?
//        字节0   字节1    字节2    字节3    字节4    字节5
//        地址    高四�?  参数1    参数2    参数3    参数4
//               参数个数
//                低四�?
//                功能�?

//                                     指令�?
//u8 Encoder_Read_Round[2]        = {0x01, 0x00};                          //读取编码器当前圈数、单圈�?
//u8 Encoder_Read_Pos_Speed[2]    = {0x01, 0x01};                          //读取编码器当前位置、转�?
//u8 Encoder_Read_Pos_Dirc[2]     = {0x01, 0x09};                          //读取编码器位置、工作方�?编码器位�?个字节，32位无符号数，高字节在前；方向信息1个字节，取值范�?-2

//u8 Encoder_Set_Addr[3]          = {0x01, 0x12, 0x02};                    //设置编码器节点地址，取值范�?1-FF
//u8 Encoder_Set_Bund[3]          = {0x01, 0x13, 0x04};                    //设置波特率，取值范�?-5。默认值为5 1:1Mhz\2:500K\3:250K\4:125K\5:100K
//u8 Encoder_Set_Mode[3]          = {0x01, 0x14, 0x02};                    //设置工作模式，取值范�?-2。默认值为1,1:查询模式 2:主动上传(当前位置和转�?
//u8 Encoder_Set_Resp[4]          = {0x01, 0x25, 0x03, 0xE8};              //设置主动上传周期，取值范�?-10000。单位：100us 默认值为10,�?0*100=1000us
//u8 Encoder_Set_Zero[3]          = {0x01, 0x16, 0xFF};                    //编码器置�?以当前位置为新的零点�?
//u8 Encoder_Set_Zero_Pos[3]      = {0x01, 0x17, 0x02};                    //设置编码器零点取值，取值范�?-2。默认值为1 此指令只对多圈编码器有效 1:中间�?2:0�?
//u8 Encoder_Set_Dirc[3]          = {0x01, 0x18, 0x02};                    //设置编码器值递增方向，取值范�?-2。默认值为1 1:顺时针工作值递增2:逆时针工作值递增
//u8 Encoder_Set_Pos[6]           = {0x01, 0x4A, 0x00, 0x00, 0x00, 0x01};  //设置编码器当前位�?测量范围内可设任意值为当前�? 此指令只对多圈编码器有效 取值范�?-0xFFFFFFFF
//u8 Encoder_Set_Speed_Capture[3] = {0x01, 0x1B, 0x0A};                    //设置速度采样周期，取值范�?1-C8�?单位�?0ms 默认值为0A,�?0*10=100ms
/**************************************************************************************/

/**************************************************************************************/
//初始化步�?一�?：设置ID->设置波特�?>设置自动上报模式->零点�?->当前位置�?->设置方向->设置速度采样周期->设置自动上报频率
// 0x01            12,01   13,04(125K)    14,02         17,02     16,FF      18,02     1B,01(10ms)     25,00,64(10ms)
//反馈数据放进数组，通过CAN1打印
//之后注释掉初始化函数
/**************************************************************************************/

/**************************************************************************************/
//位置�? 要开机发送？
//初始化（一次）->CAN中断接收位置、转�?>（中断里？）转换为线速度与长�?>通过串口DMA发送线速度�?）与长度�?）数据，控制电机与离合器
/**************************************************************************************/

extern u8 canrxbuf1[8];
static encoder_feedback_t s_encoder_feedback = {0};

u8 Encoder_Set_OneByte[3]          = {0x01, 0x00, 0x00};
u8 Encoder_Set_Resp[4]          = {0x01, 0x25, 0x00, 0x00};
u8 Encoder_Set_Pos[6]           = {0x01, 0x4A, 0x00, 0x00, 0x00, 0x01};
u16 RxRoundBuffer[2];

u8 Code[7][2] ={
    {0x12,0x01},
    {0x13,0x05},
    {0x14,0x02},
    {0x17,0x02},
    {0x16,0xFF},
    {0x18,0x02},
    {0x1B,0x01}
};

/*
 * 函数名：Encoder_Set_OneByte_Fun
 * 描述  ：发送编码器设置指令�?字节
 * 输入  ：指令代号，参数
 * 输出  :  	 
 * 调用  �?
 */
void Encoder_Set_OneByte_Fun(u8 Code, u8 Obj)
{
    Encoder_Set_OneByte[1] = Code;
    Encoder_Set_OneByte[2] = Obj;
    Can1_Send_Msg(Encoder_Set_OneByte,0x00,3);
#if APP_USART2_TEXT_DEBUG
    swgPrtUx(USART2, "\r\n transmit Ok \r\n");
#endif

#if 0 
    while(rxflag)
    {
      if(canrxbuf1[2] == 0x00)
      return;
    }
#endif
}

/*
 * 函数名：Encoder_Set_Resp_Fun
 * 描述  ：设置编码器上传周期
 * 输入  ：取值范�?0001-2710
 * 输出  :  	 
 * 调用  �?
 */
void Encoder_Set_Resp_Fun(u16 RespCode)
{
    Encoder_Set_Resp[2] = (u8)(RespCode >> 8);
    Encoder_Set_Resp[3] = (u8)RespCode;
    Can1_Send_Msg(Encoder_Set_Resp,0x00,4);
#if APP_USART2_TEXT_DEBUG
    swgPrtUx(USART2, "\r\n transmit Ok \r\n");
#endif

#if 0 
    while(rxflag)
    {
      if(canrxbuf1[2] == 0x00)
      return;
    }
#endif
}

/*
 * 函数名：Encoder_Set_Pos_Fun
 * 描述  ：设置编码器当前位置
 * 输入  ：取值范�?1-FFFFFFFF
 * 输出  :  	 
 * 调用  �?
 */
void Encoder_Set_Pos_Fun(u32 PosCode)
{
    u8 i;
    u32 timeout = 0x000FFFFFU;

    for(i = 2U; i < 6U; i++)
    {
        Encoder_Set_Pos[i] = (u8)(PosCode >> (40U - ((u32)i * 8U)));
    }

    Can1_Send_Msg(Encoder_Set_Pos, 0x00, 6U);
    while((canrxbuf1[2] == 0x00U) && (timeout > 0U))
    {
        timeout--;
    }
}

/*
 * 函数名：Encoder_Read_Round_Fun
 * 描述  ：读取编码器当前圈数、单圈�?
 * 输入  �?
 * 输出  ：圈�?个字节，16 位无符号数，高字节在�?单圈编码器固定为0x00 0x00)；单圈�?个字节，16 位无符号数，高字节在前；
 * 调用  �?
 */
void Encoder_Read_Round_Fun(void)
{
    u8 Encoder_Read_Round[2] = {0x01, 0x00};
    Can1_Send_Msg(Encoder_Read_Round,0x00,2);
     for(u8 i =0; i < 2; i++)
        {
          RxRoundBuffer[i] = (u16)((u16)canrxbuf1[2*i+2]<<8 | (u16)canrxbuf1[2*i+3]);
        }
}

/*
 * 函数名：Encoder_Read_Pos_Dirc_Fun
 * 描述  ：读取编码器当前位置、方向信�?
 * 输入  �?
 * 输出  ：编码器位置4个字节，32位无符号数，高字节在前；方向信息1个字节，取值范�?-2 1：顺时针2：逆时�?
 * 调用  �?
 */
void Encoder_Read_Pos_Dirc_Fun(void)
{
    u8 Encoder_Read_Pos_Dirc[2] = {0x01, 0x09};
    Can1_Send_Msg(Encoder_Read_Pos_Dirc,0x00,2);
    /* Keep USART2 clean for the upper-computer binary protocol. */
}

/*
 * 函数名：Solve_Length_and_Linespeed
 * 描述  ：读取编码器当前位置、转速，求解带簧实际长度与运动速度
 * 输入  ：编码器当前位置、转�?
 * 输出  ：带簧实际长度与运动速度
 * 调用  �?
 */
void Solve_Length_and_Linespeed(u8 DataArray[], u8 *Actual_Length, u8 *Actual_Speed)
{
    u32 temp_Length = ((u32)(DataArray[2]<<24)|(u32)(DataArray[3]<<16)|(u32)(DataArray[4]<<8)|(u32)(DataArray[5]));
    u16 temp_speed = (u16)(DataArray[6]<<8 | DataArray[7]);
    
    *Actual_Length = (u8)ceil(temp_Length / 1024 * Roller_Perimeter);       //unit:mm
    *Actual_Speed = (u8)ceil(temp_speed / 3);                               //unit:mm/s
}

/*
 * 函数名：Length_Control
 * 描述  ：读取带簧当前伸长长度，进行软件限位
 * 输入  ：伸长长�?
 * 输出  ：关节电机开关量
 * 调用  �?
 */
u8 Length_Control(u8 *Length)
{
    if((*Length - Length_Max) == 0)
        return ON;
    else
        return OFF;
}

/*
 * 函数名：Encoder_Init
 * 描述  ：编码器初始函数
 * 输入  ：初始化步骤(一�?：设置ID->设置波特�?>设置自动上报模式->零点�?->当前位置�?->设置方向->设置速度采样周期->设置自动上报频率
            0x01            12,01   13,04(125K)    14,02         17,02     16,FF      18,02     1B,01(10ms)     25,00,64(10ms)
 * 输出  ：串�?调试信息,接收一�?8�?0�?x01 0x59�?�?x00 0x06 0x03 0x27）（未知�?0x01or02 �?5个字节有效数�?
 * 调用  �?
 */
void Encoder_Init(void)              
{
    static u8 i,j,k;
    
    for(i=0;i<7;i++)
        {
         for(j=0,k=1;j<2 && k<3;j++,k++)
           {
            Encoder_Set_OneByte[k] = Code[i][j];
           }
         Can1_Send_Msg(Encoder_Set_OneByte,0x00,3); 
        }
    Encoder_Set_Resp_Fun(0x64);//最后一�?设置广播频率
    Encoder_Read_Pos_Dirc_Fun();//读取当前位置、方�?

}

void Encoder_OnCanFrame(u32 std_id, const u8 *data, u8 len)
{
    u32 raw_position;
    s16 raw_speed;

    (void)std_id;

    if((data == 0) || (len < 8U))
    {
        return;
    }

    raw_position = ((u32)data[2] << 24) |
                   ((u32)data[3] << 16) |
                   ((u32)data[4] << 8)  |
                   ((u32)data[5]);
    raw_speed = (s16)(((u16)data[6] << 8) | (u16)data[7]);

    s_encoder_feedback.raw_position = raw_position;
    s_encoder_feedback.raw_speed = raw_speed;
    s_encoder_feedback.length_mm = (s32)((raw_position * Roller_Perimeter) / 1024U);
    s_encoder_feedback.line_speed_mm_s = (s16)(raw_speed / 3);
    s_encoder_feedback.direction = data[1];
    s_encoder_feedback.valid = 1U;
}

const encoder_feedback_t *Encoder_GetFeedback(void)
{
    return &s_encoder_feedback;
}
/******************* (C) COPYRIGHT 2024 END OF FILE *****************************/
