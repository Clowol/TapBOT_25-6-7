/******************** (C) COPYRIGHT 2026 *****************************************
   * @author      Clomol
   * @date        2026-2027
   * @brief       DMA方式读取ADC值应用函数库 
   * @license     [z]本代码仅用于教学与科研目的，未经作者书面许可，不得用于商业用�?
   *              This project is released under the MIT License.
   * @note        
   * @warning     
*********************************************************************************/
/**
 *  硬件配置�?--------------------------------------------------------
 *            ADC1	STM32_AD1�?PA0   ADC_IN0		  重标：J46		AD2
 *        后面要改	 STM32_AD2�?PA2   ADC_IN2				J50		AD1
 *               	  STM32_AD3�?PA3   ADC_IN3				J54		AD8
 *               	  STM32_AD4�?PA6   ADC_IN6				J56		AD7
 *               	  STM32_AD5�?PA7   ADC_IN7				J47		AD10
 *               	  STM32_AD6�?PB0   ADC_IN8				J51		AD9
 *               	  STM32_AD7�?PB1   ADC_IN9				J55		AD4
 *                	STM32_AD8�?PC0   ADC_IN10				J57		AD3
 *               	  STM32_AD9�?PC1   ADC_IN11				J48		AD6
 *               	  STM32_AD10：PC2   ADC_IN12				J52		AD5
 * 
 *  电阻测量 0-190�?  AIN1			PC3		ADC_IN13	J49
 *					           AIN2			   PC4		ADC_IN14	J53
 *              ---------------------------------------------------------
 */ 

#include "adc.h"


/*************************** 全局变量定义*******************************/
volatile u16 ADC_ConvertedValue[SCAN_TIMES][CHANNEL_NUM];
volatile u16 ADC_FilteredValue[CHANNEL_NUM];


/*************************** 函数定义*******************************/

/**********************************************************************************************
 * @name 	  ADC1_GPIO_Config(void)
 * @brief   配置ADC1通道对应的GPIO引脚
 * @param   �?
 * @retval  �?
 * @note    使能ADC1和DMA1的时钟，初始化PA  PB  PC->模拟输入模式（AIN�?
 *          [内部调用]
 **********************************************************************************************/
static void ADC1_GPIO_Config(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;

	/* Enable ADC1 and GPIOA GPIOB GPIOC clock */
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1 | RCC_APB2Periph_GPIOA   \
	| RCC_APB2Periph_GPIOB | RCC_APB2Periph_GPIOC, ENABLE);

  /* Configure PA PB  PC as analog input */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_6|GPIO_Pin_7;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_Init(GPIOA, &GPIO_InitStructure);				// 输入时不用设置速率
	
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0|GPIO_Pin_1;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_Init(GPIOB, &GPIO_InitStructure);				// 输入时不用设置速率

  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_Init(GPIOC, &GPIO_InitStructure);				// 输入时不用设置速率	
}



/**********************************************************************************************
 * @name 	  ADC1_Mode_Config(void)
 * @brief   配置ADC1工作模式
 * @param   �?  
 * DC1,ADC通道x,规则采样顺序值为y,采样时间�?39.5周期
 * 12个通道
 * ADC_RegularChannelConfig(ADC1, ADC_Channel_0, 1, ADC_SampleTime_239Cycles5 );
 * ADC_RegularChannelConfig(ADC1, ADC_Channel_2, 2, ADC_SampleTime_239Cycles5 );
 * ADC_RegularChannelConfig(ADC1, ADC_Channel_3, 3, ADC_SampleTime_239Cycles5 );
 * ADC_RegularChannelConfig(ADC1, ADC_Channel_6, 4, ADC_SampleTime_239Cycles5 );
 * ADC_RegularChannelConfig(ADC1, ADC_Channel_7, 5, ADC_SampleTime_239Cycles5 );
 * ADC_RegularChannelConfig(ADC1, ADC_Channel_8, 6, ADC_SampleTime_239Cycles5 );
 * ADC_RegularChannelConfig(ADC1, ADC_Channel_9, 7, ADC_SampleTime_239Cycles5 );
 * ADC_RegularChannelConfig(ADC1, ADC_Channel_10, 8, ADC_SampleTime_239Cycles5 );
 * ADC_RegularChannelConfig(ADC1, ADC_Channel_11, 9, ADC_SampleTime_239Cycles5 );
 * ADC_RegularChannelConfig(ADC1, ADC_Channel_12, 10, ADC_SampleTime_239Cycles5 );
 * ADC_RegularChannelConfig(ADC1, ADC_Channel_13, 11, ADC_SampleTime_239Cycles5 );
 * ADC_RegularChannelConfig(ADC1, ADC_Channel_14, 12, ADC_SampleTime_239Cycles5 );
 * @retval  �?
 * @note    配置ADC1  3.3V  4096  12位； 采样时间239.5个周�?
 *          [内部调用]
 **********************************************************************************************/
static void ADC1_Mode_Config(void)
{
	ADC_InitTypeDef ADC_InitStructure;
  
  ADC_DeInit(ADC1);                               // 复位ADC1寄存器至默认�?
    
  /* ADC1 configuration */
  ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;      // 独立模式
  ADC_InitStructure.ADC_ScanConvMode = ENABLE;            // 扫描模式
  ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;      // 连续转换模式
  ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;   // 外部触发转换关闭
  ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;  // ADC数据右对�?
  ADC_InitStructure.ADC_NbrOfChannel = CHANNEL_NUM;       // 顺序进行规则转换的ADC通道的数�?
  ADC_Init(ADC1, &ADC_InitStructure);                     // 根据ADC_InitStruct中指定的参数初始化外设ADCx的寄存器

  /* 配置规则通道 */
  // 设置指定ADC的规则组通道，设置它们的转化顺序和采样时�?
  ADC_RegularChannelConfig(ADC1, ADC_Channel_11, 1, ADC_SampleTime_239Cycles5 );
  ADC_RegularChannelConfig(ADC1, ADC_Channel_12, 2, ADC_SampleTime_239Cycles5 );
  ADC_RegularChannelConfig(ADC1, ADC_Channel_13, 3, ADC_SampleTime_239Cycles5 );
  ADC_RegularChannelConfig(ADC1, ADC_Channel_14, 4, ADC_SampleTime_239Cycles5 );

  /* 使能ADC1 DMA功能 */
  ADC_DMACmd(ADC1, ENABLE);    // 开启ADC的DMA支持（要实现DMA功能，还需独立配置DMA通道等参数）
  
  /* 使能ADC1并执行校�?*/
  ADC_Cmd(ADC1, ENABLE);     

  ADC_ResetCalibration(ADC1);                     // 复位校准寄存�?
  while(ADC_GetResetCalibrationStatus(ADC1));     // 获取ADC1复位校准寄存器的状�?设置状态则等待
  ADC_StartCalibration(ADC1);                     // 开始指定ADC1的校准状�?
  while(ADC_GetCalibrationStatus(ADC1));          // 获取指定ADC1的校准程�?设置状态则等待
}



/**********************************************************************************************
 * @name 	  DMA_ADC1_Configuration(void)
 * @brief   配置ADC1的DMA通道
 * @param   �?
 * @retval  �?
 * @note    配置ADC1的DMA通道，用于自动采集ADC数据
 *          [内部调用]
 **********************************************************************************************/
static void DMA_ADC1_Configuration(void)
{
	DMA_InitTypeDef DMA_InitStructure;

	/* 使能DMA1时钟 */
  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);

	/* DMA channel1 configuration */
  DMA_DeInit(DMA1_Channel1);     // 将DMA的通道1寄存器重设为缺省�?

  /* DMA核心配置 */
  DMA_InitStructure.DMA_PeripheralBaseAddr = (u32)&ADC1->DR;         // 外设基地址（ADC1数据寄存器）
  DMA_InitStructure.DMA_MemoryBaseAddr = (u32)&ADC_ConvertedValue;   // 内存基地址（原始采样值）
  DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC;                 // 外设→内�?
  DMA_InitStructure.DMA_BufferSize = CHANNEL_NUM * SCAN_TIMES;       // 缓存大小�?*20=80�?
  DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;   // 外设地址不递增
  DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;            // 内存地址递增
  DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;     //数据宽度�?6�?
  DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;             //数据宽度�?6�?
  DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;                    // 循环模式（持续采集）
  DMA_InitStructure.DMA_Priority = DMA_Priority_High;                // DMA通道x 拥有高优先级
  DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;                       // DMA通道x 禁止内存→内�?

  DMA_Init(DMA1_Channel1, &DMA_InitStructure);                       //根据DMA_InitStruct中指定的参数初始化DMA的通道
}



/**********************************************************************************************
 * @name 	  ADC1_Init(void)
 * @brief   初始化ADC1
 * @param   �?
 * @retval  �?
 * @note    初始化ADC1，包括GPIO配置、模式配置和DMA配置
 *          [外部调用]
 **********************************************************************************************/
void ADC1_Init(void)
{
  ADC1_GPIO_Config();
  ADC1_Mode_Config();
  DMA_ADC1_Configuration();
	
  /* 启动ADC软件转换 + DMA通道 */
  ADC_SoftwareStartConvCmd(ADC1, ENABLE); //启动AD1转换  
  DMA_Cmd(DMA1_Channel1, ENABLE);         //启动DMA通道  
}


/**********************************************************************************************
 * @name 	  GetVolt(u16 advalue)
 * @brief   获得电压�?
 * @param   advalue ADC采集�?
 * @retval  电压�?
 * @note    采集值经过运算放大器变化0-5V范围内，方便下面求出小数
 *          [外部调用]
 **********************************************************************************************/
float GetVolt(u16 advalue)  
{
  return (5.0 * advalue / 4096); 
  //采集值经过运算放大器变化0-5V范围内，方便下面求出小数
}



/**********************************************************************************************
 * @name 	  GetRes(u16 advalue)
 * @brief   获得电阻�?0-190�?
 * @param   advalue ADC采集�?
 * @retval  电阻�?
 * @note    采集值经过运算放大器变化0-5V范围内，方便下面求出小数
 *          [外部调用]
 **********************************************************************************************/
float GetRes(u16 advalue)  
{
  return (5.0 * advalue / 4096); //
}
/**********************************************************************************************
 * @name 	  ADC1_GetCurrent(u16 adc_value) 
 * @brief   ADC值转换为电流值（4-20mA�?
 * @param   adc_value
 * @retval  电流值（单位：mA�?
 * @note    电流 = ((ADC�?- 最小ADC�? / ADC范围) * 电流范围 + 最小电�?
 *          [外部-调用]
 **********************************************************************************************/
float GetCurrent(u16 advalue)  
{
  return ((float)(advalue-750)/(3735-750)*16+4); //
}



/**********************************************************************************************
 * @name 	  AD_filter(void)
 * @brief   ADC数据均值滤波函�?
 * @param   �?
 * @retval  �?
 * @note    
 **********************************************************************************************/
void AD_filter(void)
{
  int sum = 0;
  u8 count,i;

  for(i=0;i<CHANNEL_NUM;i++)
  { 
    for(count=0;count<SCAN_TIMES;count++)
    {                       
      sum += ADC_ConvertedValue[count][i];  
    }  

    ADC_FilteredValue[i]=sum/SCAN_TIMES;   
    sum=0;
  }   
}


/******************* (C) COPYRIGHT 2026 END OF FILE ***************************/
